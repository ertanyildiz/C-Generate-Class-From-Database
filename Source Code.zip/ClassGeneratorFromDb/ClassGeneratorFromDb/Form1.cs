﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Char;

namespace ClassGeneratorFromDb
{
    public partial class Form1 : Form
    {
        SqlConnection _cnn;
        public Form1()
        {
            InitializeComponent();
        }
     
        private void btnConnect_Click(object sender, EventArgs e)
        {
            ConnectDatabase();
        }

        /// <summary>
        /// Connects to given server from form controls. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ConnectDatabase()
        {
            var connString = $"Data Source={txtServerName.Text};User ID={txtUserName.Text};Password={txtPass.Text}";
            _cnn = new SqlConnection(connString);
            var dbDataTable = new DataTable();
            try
            {
                _cnn.Open();
                using (var cmd = new SqlCommand("SELECT name as [DbName] from sys.databases", _cnn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(dbDataTable);
                }

                comboDbList.DataSource = dbDataTable;
                comboDbList.DisplayMember = "DbName";
                comboDbList.ValueMember = "DbName";

                groupBox1.Enabled = true;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! " + ex.Message);
            }
        }

        //creates 
        private void btnCreate_Click(object sender, EventArgs e)
        {
            CreateClass();
        }

        /// <summary>
        /// Creates class from given information on the form
        /// </summary>
        private void CreateClass()
        {
            try
            {
                if (!CheckForm())
                {
                    MessageBox.Show("Fill all fields!", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (_cnn.State == ConnectionState.Closed)
                {
                    _cnn.Open();
                }

                var path = $"{AppDomain.CurrentDomain.BaseDirectory}/{txtClassName.Text}.cs";

                File.Delete(path);

                var sorgu = "SELECT \' public \' + ColumnType + NullableSign + \' \' AS [CTYPE], ColumnName AS CNAME\r\nfrom\r\n(\r\n    select \r\n        replace(col.name, \' \', \'_\') ColumnName,\r\n        column_id ColumnId,\r\n        case typ.name \r\n            when \'bigint\' then \'long\'\r\n            when \'binary\' then \'byte[]\'\r\n            when \'bit\' then \'bool\'\r\n            when \'char\' then \'string\'\r\n            when \'date\' then \'DateTime\'\r\n            when \'datetime\' then \'DateTime\'\r\n            when \'datetime2\' then \'DateTime\'\r\n            when \'datetimeoffset\' then \'DateTimeOffset\'\r\n            when \'decimal\' then \'decimal\'\r\n            when \'float\' then \'float\'\r\n            when \'image\' then \'byte[]\'\r\n            when \'int\' then \'int\'\r\n            when \'money\' then \'decimal\'\r\n            when \'nchar\' then \'string\'\r\n            when \'ntext\' then \'string\'\r\n            when \'numeric\' then \'decimal\'\r\n            when \'nvarchar\' then \'string\'\r\n            when \'real\' then \'double\'\r\n            when \'smalldatetime\' then \'DateTime\'\r\n            when \'smallint\' then \'short\'\r\n            when \'smallmoney\' then \'decimal\'\r\n            when \'text\' then \'string\'\r\n            when \'time\' then \'TimeSpan\'\r\n            when \'timestamp\' then \'DateTime\'\r\n            when \'tinyint\' then \'byte\'\r\n            when \'uniqueidentifier\' then \'Guid\'\r\n            when \'varbinary\' then \'byte[]\'\r\n            when \'varchar\' then \'string\'\r\n            else \'UNKNOWN_\' + typ.name\r\n        end ColumnType,\r\n        case \r\n            when col.is_nullable = 1 and typ.name in (\'bigint\', \'bit\', \'date\', \'datetime\', \'datetime2\', \'datetimeoffset\', \'decimal\', \'float\', \'int\', \'money\', \'numeric\', \'real\', \'smalldatetime\', \'smallint\', \'smallmoney\', \'time\', \'tinyint\', \'uniqueidentifier\') \r\n            then \'?\' \r\n            else \'\' \r\n        end NullableSign\r\n    from sys.columns col\r\n        join sys.types typ on\r\n            col.system_type_id = typ.system_type_id AND col.user_type_id = typ.user_type_id\r\n    where object_id = object_id(\'" + comboTables.SelectedItem + "\')\r\n) t\r\norder by ColumnId";


                using (var sw = File.AppendText(path))
                {
                    sw.Write("using System;{0}", Environment.NewLine);
                    sw.Write("{0}", Environment.NewLine);
                    sw.Write("namespace {0}", txtNameSpace.Text + Environment.NewLine);
                    sw.Write("{0}", "{" + Environment.NewLine);
                    sw.Write("\tpublic class {0}", txtClassName.Text + Environment.NewLine);
                    sw.Write("{0}", "\t{" + Environment.NewLine);
                    var cmd = new SqlCommand
                    {
                        CommandText = sorgu,
                        CommandType = CommandType.Text,
                        Connection = _cnn
                    };


                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var camelName = EditColumnName(reader[1].ToString());
                        var sonuc = reader[0] + camelName + " {get; set;}";
                        sw.WriteLine("\t\t{0}", sonuc);
                        sw.Write("{0}", Environment.NewLine);
                    }
                    sw.Write("{0}", "\t}" + Environment.NewLine);
                    _cnn.Close();
                    sw.Write("{0}", Environment.NewLine);
                    sw.Write("{0}", "}" + Environment.NewLine);

                    MessageBox.Show($"{txtClassName.Text}.cs created.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Process.Start(AppDomain.CurrentDomain.BaseDirectory);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }


        /// <summary>
        /// Determines whether form inputs are valid or not.
        /// </summary>
        /// <returns></returns>
        private bool CheckForm()
        {
            return !string.IsNullOrEmpty(txtClassName.Text) && !string.IsNullOrEmpty(txtNameSpace.Text) &&
                   comboDbList.SelectedIndex > -1 && comboTables.SelectedIndex > -1;
        }

        /// <summary>
        /// Removes dashes from colum name. 
        /// Makes Uppercase each word in colum name. 
        /// </summary>
        /// <param name="columName"></param>
        /// <returns></returns>
        private string EditColumnName(string columName)
        {
            
            if (columName.Length == 0)
            {
                return columName;
            }

            var sb = new StringBuilder(columName.ToLowerInvariant());
            sb[0] = ToUpperInvariant(sb[0]);

            for (int i = 0; i < sb.Length; i++)
            {
                if (sb[i] == '_' || sb[i] == '-')
                {
                    sb.Remove(i, 1);
                    if (i != sb.Length)
                    {
                        sb[i] = ToUpper(sb[i], new CultureInfo("en-EN"));
                    }
                    
                }
            }
            return sb.ToString();
        }


        /// <summary>
        /// Populates column names from selected database.
        /// </summary>
        private void PopulateTables()
        {
            var connString = $"Data Source={txtServerName.Text};Initial Catalog={comboDbList.SelectedValue};User ID={txtUserName.Text};Password={txtPass.Text}";
            _cnn = new SqlConnection(connString);
            _cnn.Open();
            var tables = _cnn.GetSchema("Tables");
            comboTables.Items.Clear();
            foreach (DataRow tablesRow in tables.Rows)
            {
                comboTables.Items.Add(tablesRow[2].ToString());
            }
        }

        private void comboDbList_SelectionChangeCommitted(object sender, EventArgs e)
        {
            PopulateTables();
        }
    }
}
